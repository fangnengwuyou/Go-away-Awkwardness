Page({
  data: {
    src3: '/pages/image/4.jpg',
    
  },
  
  initialAudio: function () {
    let audioCtx = this.audioCtx
    audioCtx.autoplay = false
    audioCtx.play()
    audioCtx.src = '/pages/image/灯光 .m4a'
    audioCtx.onPlay(() => {
      console.log('开始播放')
    })
    audioCtx.onPause((res) => {
      console.log('停止播放')
    })
    audioCtx.onStop((res) => {
      console.log('暂停播放')
    })
  },
  play: function () {
    this.audioCtx.play()
  },
  pause: function () {
    this.audioCtx.pause()
  },
  stop: function () {
    this.audioCtx.stop()
  },
  onLoad: function (options) {
    this.audioCtx = wx.createInnerAudioContext()
    this.initialAudio()
  }
})