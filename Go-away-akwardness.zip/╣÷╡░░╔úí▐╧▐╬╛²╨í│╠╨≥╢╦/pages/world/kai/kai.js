const devicesId = "561893845"
const api_key = "s8myo2RVqRU6qVFrc46unodvbEY="
Page({
  data: {
    src: '/pages/image/1.png',
    src1: '/pages/image/2.jpg',
    value1: '',
    value2: ''
  },
  //跳转到天气页面
  navigate: function () {
    wx.navigateTo({
      url: '../world/hello/hello',
    })
  },
  navigate1: function () {
    wx.navigateTo({
      url: '../world/kun/kun',
    })
  },
  onPullDownRefresh: function () {
    console.log("我正在下拉刷新")

    this.getDatapoints().then(datapoints => {
      this.update(datapoints)
      wx.hideLoading()
    }).catch((err) => {
      wx.hideLoading()

    })
  },
  onLoad: function () {
    console.log(`your deviceId: ${devicesId}, apiKey: ${api_key}`)

    const timer = setInterval(() => {
      this.getDatapoints().then(datapoints => {
        this.update(datapoints)
      })
    }, 1000)

    wx.showLoading({
      title: '加载中'
    })

    this.getDatapoints().then((datapoints) => {
      wx.hideLoading()

    }).catch((err) => {
      wx.hideLoading()
      console.error(err)
      clearInterval(timer)
    })
  },
  update: function (datapoints) {
    const wheatherData = 1
  },
  getDatapoints: function () {
    return new Promise((resolve, reject) => {
      wx.request({
        url: `https://api.heclouds.com/devices/${devicesId}/datapoints?datastream_id=light,mic`,

        header: {
          'content-type': 'application/json',
          'api-key': api_key
        },
        success: (res) => {

          const status = res.statusCode
          const response = res.data
          var value = response.data.datastreams[0].datapoints[0].value
          var thevalue = response.data.datastreams[1].datapoints[0].value
          this.setData({
            value1: value,
            value2: thevalue
          })
          if (status !== 200) {
            reject(res.data)
          }
          if (response.errno !== 0) {
            reject(response.error)
          }
          console.log(res)
          resolve({

            mic: response.data.datastreams[0].datapoints.reverse(),
            light: response.data.datastreams[1].datapoints.reverse()
          })
        },
        fail: (err) => {
          reject(err)
        }
      })
    })
  }
})