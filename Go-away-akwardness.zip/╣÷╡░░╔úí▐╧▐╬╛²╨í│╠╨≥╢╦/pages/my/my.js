Page({
  data:{
    num:0
  },
  //获取微信用户信息
  getMyInfo:function(e){
    let info =e.detail.userInfo;
    this.setData({
      isLogin:true,
      src:info.avatarUrl,
      nickName:info.nickName
    })
  },
  navigate: function () {
    wx.navigateTo({
      url: '../world/kai/kai',
    })
  }
})